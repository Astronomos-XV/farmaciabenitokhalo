const express = require('express');
const fs = require('fs').promises; // Usando promesas para un manejo ansincrono
const path = require('path');

const app = express();
const PORT = 3000;
const DATA_FILE = path.join(__dirname, 'data.json');

// Parsear el .json
app.use(express.json());

// Metodo que se usa para leer los archivos .json
async function readData() {
    try {
        const data = await fs.readFile(DATA_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return []; // Salta si hay un error o el archivo no existe
    }
}

// Metodo auxiliar para leer archivos.json
async function writeData(data) {
    await fs.writeFile(DATA_FILE, JSON.stringify(data, null, 2));
}

// Ruta raíz
app.get('/', (req, res) => {
    res.send('API CRUD funcionando');
});

// CREATE = Agrega un nuevo elemento
app.post('/merca', async (req, res) => {
    try {
        const items = await readData();
        const newItem = {
            id: items.length > 0 ? items[items.length - 1].id + 1 : 1,
            ...req.body,
            creado: new Date().toLocaleString('es-ES', { timeZone: 'America/Caracas' })
        };
        items.push(newItem);
        await writeData(items);
        res.status(201).json(newItem);
    } catch (error) {
        res.status(500).json({ error: 'Error al crear el item' });
    }
});

// READ = para mostrar todos los elementos = Obtencion de todos los elementos
app.get('/merca', async (req, res) => {
    try {
        const items = await readData();
        res.json(items);
    } catch (error) {
        res.status(500).json({ error: 'Error al leer los items' });
    }
});

// Metodo de lectura por ID = Obtiene un elemento por ID
app.get('/merca/:id', async (req, res) => {
    try {
        const items = await readData();
        const item = items.find(i => i.id === parseInt(req.params.id));
        if (!item) {
            return res.status(404).json({ error: 'Item no encontrado' });
        }
        res.json(item);
    } catch (error) {
        res.status(500).json({ error: 'Error al buscar el item' });
    }
});

// UPDATE = Se Actualiza un elemento  por ID
app.put('/merca/:id', async (req, res) => {
    try {
        const items = await readData();
        const index = items.findIndex(i => i.id === parseInt(req.params.id));
        if (index === -1) {
            return res.status(404).json({ error: 'Item no encontrado' });
        }
        items[index] = {
            ...items[index],
            ...req.body,
            id: items[index].id, // ID ORIGINAL
            actualizado: new Date().toLocaleString('es-ES', { timeZone: 'America/Caracas' })
        };
        await writeData(items);
        res.json(items[index]);
    } catch (error) {
        res.status(500).json({ error: 'Error al actualizar el item' });
    }
});

// DELETE = Sentar de un coñazo un elemento(Eliminarlo)
app.delete('/merca/:id', async (req, res) => {
    try {
        const items = await readData();
        const initialLength = items.length;
        const filteredItems = items.filter(i => i.id !== parseInt(req.params.id));
        if (filteredItems.length === initialLength) {
            return res.status(404).json({ error: 'Item no encontrado' });
        }
        await writeData(filteredItems);
        res.status(204).send();
    } catch (error) {
        res.status(500).json({ error: 'Error al eliminar el item' });
    }
});

// Metodo para iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});